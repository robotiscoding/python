# 다음과 같이 import를 사용할 수 있습니다.
# import math
def solution(numberA, numberB, limit):
    d1 = 0
    d2 = 1
    set1 = set()
    while True:
        if numberA * d1 > limit:
            break
        result = numberA * d1 + numberB * d2
        if result <= limit:
            set1.add(result)
            d2 += 1
        else:
            d1 += 1
            d2 = 0
    print(set1)
    return len(set1)

# 아래는 테스트케이스 출력을 해보기 위한 코드입니다. 
numberA1 = 2
numberB1 = 4
limit1 = 10
ret1 = solution(numberA1, numberB1, limit1)

# [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret1, "입니다.")

numberA2 = 2
numberB2 = 3
limit2 = 10
ret2 = solution(numberA2, numberB2, limit2)

# [실행] 버튼을 누르면 출력 값을 볼 수 있습니다.
print("solution 함수의 반환 값은", ret2, "입니다.")

